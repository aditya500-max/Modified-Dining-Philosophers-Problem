#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
sem_t sauceBowls[2];
sem_t forks[5];

void * philosopher(void * arg) {
	int id = (int) arg;
	while(1) {
		if (id % 2 == 0) {
			sem_wait(&forks[id]);
			sem_wait(&forks[(id + 1) % 5]);
		} 
		else {
			sem_wait(&forks[(id + 1) % 5]);
			sem_wait(&forks[id]);
		}
		sem_wait(&sauceBowls[id%2]);
		printf("Philosopher %d is eating\n", id);
		sem_post(&sauceBowls[id%2]);
		sem_post(&forks[id]);
		sem_post(&forks[(id + 1) % 5]);
	}
}
int main() {
	int i;
	pthread_t ph[5];
	int args[5];
	for (i = 0; i < 5; i++) {
		sem_init(&forks[i], 0, 1);
	}
	for (i = 0; i < 2; i++) {
		sem_init(&sauceBowls[i], 0, 1);
	}
	for (i = 0; i < 5; i++) {
		args[i] = i;
		pthread_create(&ph[i], NULL, philosopher, &args[i]);
	}
	for (i = 0; i < 5; i++) {
		pthread_join(ph[i], NULL);
	}
	return 0;
}